package com.spyderscience.inventorymanagementjava.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.spyderscience.inventorymanagementjava.model.ProductsModel;
import com.spyderscience.inventorymanagementjava.model.UsersModel;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "inventory_management_app";
    private static final String TABLE_USERS = "users_table";
    private static final String TABLE_PRODUCTS = "products_table";

    // Columns for Users Table
    private static final String KEY_ID_USER = "user_id";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_PHONE = "phone";
    private static final String KEY_PASSWORD = "password";

    // Columns for Products Table
    private static final String KEY_PRODUCTS_ID = "product_id";
    private static final String KEY_PRODUCTS_NAME = "product_name";
    private static final String KEY_PRODUCTS_QUANTITY = "product_quantity";
    private static final String KEY_PRODUCTS_IMAGE = "product_image";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String createUserTableQuery = "CREATE TABLE " + TABLE_USERS + "(" +
                KEY_ID_USER + " INTEGER PRIMARY KEY," +
                KEY_EMAIL + " TEXT NOT NULL," +
                KEY_PHONE + " TEXT NOT NULL," +
                KEY_PASSWORD + " TEXT NOT NULL)";
        db.execSQL(createUserTableQuery);

        // Create Products Table
        String createProductsTableQuery = "CREATE TABLE " + TABLE_PRODUCTS + "(" +
                KEY_PRODUCTS_ID + " INTEGER PRIMARY KEY," +
                KEY_ID_USER + " INTEGER NOT NULL," +
                KEY_PRODUCTS_NAME + " TEXT NOT NULL," +
                KEY_PRODUCTS_QUANTITY + " TEXT NOT NULL," +
                KEY_PRODUCTS_IMAGE + " TEXT NOT NULL)";
        db.execSQL(createProductsTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if existed and create them again
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRODUCTS);
        onCreate(db);
    }

    // Method to register a user
    public void registerUser(UsersModel user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_EMAIL, user.getEmail());
        values.put(KEY_PHONE, user.getPhone());
        values.put(KEY_PASSWORD, user.getPassword());

        db.insert(TABLE_USERS, null, values);
        db.close();
    }

    // Method to get all users
    @SuppressLint("Range")
    public List<UsersModel> getAllUsers() {
        List<UsersModel> userList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_USERS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                UsersModel user = new UsersModel();
                user.setId(cursor.getInt(cursor.getColumnIndex(KEY_ID_USER)));
                user.setEmail(cursor.getString(cursor.getColumnIndex(KEY_EMAIL)));
                user.setPhone(cursor.getString(cursor.getColumnIndex(KEY_PHONE)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(KEY_PASSWORD)));

                userList.add(user);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return userList;
    }

    // Method to insert a product
    public void insertProduct(ProductsModel product) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_ID_USER, product.getUserId());
        values.put(KEY_PRODUCTS_NAME, product.getName());
        values.put(KEY_PRODUCTS_QUANTITY, product.getQuantity());
        values.put(KEY_PRODUCTS_IMAGE, product.getImageUri());

        db.insert(TABLE_PRODUCTS, null, values);
        db.close();
    }

    // Method to get products by user ID
    @SuppressLint("Range")
    public List<ProductsModel> getProductsByUserId(int userId) {
        List<ProductsModel> productList = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_PRODUCTS +
                " WHERE " + KEY_ID_USER + " = ?";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(userId)});

        if (cursor.moveToFirst()) {
            do {
                ProductsModel product = new ProductsModel();
                product.setProductId(cursor.getInt(cursor.getColumnIndex(KEY_PRODUCTS_ID)));
                product.setUserId(cursor.getInt(cursor.getColumnIndex(KEY_ID_USER)));
                product.setName(cursor.getString(cursor.getColumnIndex(KEY_PRODUCTS_NAME)));
                product.setQuantity(cursor.getString(cursor.getColumnIndex(KEY_PRODUCTS_QUANTITY)));
                product.setImageUri(cursor.getString(cursor.getColumnIndex(KEY_PRODUCTS_IMAGE)));

                productList.add(product);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return productList;
    }

    // Method to update a product
    public void updateProduct(ProductsModel product) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_PRODUCTS_NAME, product.getName());
        values.put(KEY_PRODUCTS_QUANTITY, product.getQuantity());
        values.put(KEY_PRODUCTS_IMAGE, product.getImageUri());

        db.update(TABLE_PRODUCTS, values, KEY_PRODUCTS_ID + " = ?",
                new String[]{String.valueOf(product.getProductId())});
        db.close();
    }

    // Method to delete a product
    public void deleteProduct(int productId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_PRODUCTS, KEY_PRODUCTS_ID + " = ?",
                new String[]{String.valueOf(productId)});
        db.close();
    }
}
