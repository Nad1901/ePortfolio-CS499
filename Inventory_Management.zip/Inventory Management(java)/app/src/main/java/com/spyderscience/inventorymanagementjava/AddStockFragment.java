package com.spyderscience.inventorymanagementjava;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.spyderscience.inventorymanagementjava.database.DatabaseHelper;
import com.spyderscience.inventorymanagementjava.databinding.FragmentAddStockBinding;
import com.spyderscience.inventorymanagementjava.model.HelperClass;
import com.spyderscience.inventorymanagementjava.model.ProductsModel;
import com.spyderscience.inventorymanagementjava.model.UsersModel;

public class AddStockFragment extends Fragment {
    private FragmentAddStockBinding binding;
    private String name, quantity, imageUri = ""; // Declare variables
    private DatabaseHelper databaseHelper;
    private int request_code = 123; // Request code for permissions

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentAddStockBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Setup bottom navigation view
        BottomNavigationView bottomNav = view.findViewById(R.id.bottomNavigationView);
        NavHostFragment navHostFragment = (NavHostFragment) requireActivity().getSupportFragmentManager()
                .findFragmentById(R.id.bottomNavigationView);
        if (navHostFragment != null) {
            NavigationUI.setupWithNavController(bottomNav, navHostFragment.getNavController());
        }

        // Initialize database helper
        databaseHelper = new DatabaseHelper(requireContext());

        // Pick image button click listener
        binding.imageIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open image picker
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("image/*");
                startActivityForResult(intent, 100);
            }
        });

        // Add item button click listener
        binding.addItemBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValidated()){
                    // Create products model
                    ProductsModel productsModel = new ProductsModel(HelperClass.users.getId(), name, quantity, imageUri);
                    // Send SMS notification if quantity is less than 5
                    if (Integer.parseInt(quantity) < 5){
                        sendSMSNotification(productsModel);
                    }
                    // Insert product into database
                    databaseHelper.insertProduct(productsModel);
                    // Navigate to manage stock fragment
                    NavHostFragment.findNavController(AddStockFragment.this)
                            .navigate(R.id.action_addStockFragment_to_manageStockFragment2);
                    // Show success message
                    Toast.makeText(requireContext(), "Add Item Successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to validate input fields
    private Boolean isValidated(){
        name = binding.itemNameET.getText().toString().trim();
        quantity = binding.itemQuantity.getText().toString().trim();

        if (imageUri.isEmpty()){
            showMessage("Please pick image");
            return false;
        }

        if (name.isEmpty()){
            showMessage("Please enter name");
            return false;
        }

        if (quantity.isEmpty()){
            showMessage("Please enter quantity");
            return false;
        }

        return true;
    }

    // Method to display toast message
    private void showMessage(String message){
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }

    // Handle result from image picker
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            imageUri = data.getData().toString();
            binding.uploadImage.setImageURI(data.getData());
        }
    }

    // Send SMS notification about low inventory
    private void sendSMSNotification(ProductsModel productsModel) {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(HelperClass.users.getPhone(), null, productsModel.getName()+" has low inventory, Please make sure the quantity 5 or above", null, null);
        }
    }

}
