package com.spyderscience.inventorymanagementjava.model;

public class HelperClass {
    public static UsersModel users;
}
