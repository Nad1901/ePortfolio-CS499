package com.spyderscience.inventorymanagementjava.model;

import java.io.Serializable;

public class ProductsModel implements Serializable {
    int productId, userId;
    String name, quantity, imageUri;

    public ProductsModel() {
    }

    public ProductsModel(int userId, String name, String quantity, String imageUri) {
        this.userId = userId;
        this.name = name;
        this.quantity = quantity;
        this.imageUri = imageUri;
    }

    public ProductsModel(int productId, int userId, String name, String quantity, String imageUri) {
        this.productId = productId;
        this.userId = userId;
        this.name = name;
        this.quantity = quantity;
        this.imageUri = imageUri;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }
}
