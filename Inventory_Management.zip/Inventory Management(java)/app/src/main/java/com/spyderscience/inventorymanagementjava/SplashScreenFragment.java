package com.spyderscience.inventorymanagementjava;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.spyderscience.inventorymanagementjava.databinding.FragmentSplashScreenBinding;


public class SplashScreenFragment extends Fragment {

    private FragmentSplashScreenBinding binding;
    private final long splashTime = 2000;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentSplashScreenBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initialize();
    }

    private void initialize() {
        View appLogo = binding.logo;

        Animation topAnim = AnimationUtils.loadAnimation(
                requireContext(),
                androidx.appcompat.R.anim.abc_slide_in_top
        );
        appLogo.startAnimation(topAnim);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                NavHostFragment.findNavController(SplashScreenFragment.this)
                        .navigate(R.id.action_splashScreenFragment_to_splashScreen2Fragment);
            }
        }, splashTime);
    }
}