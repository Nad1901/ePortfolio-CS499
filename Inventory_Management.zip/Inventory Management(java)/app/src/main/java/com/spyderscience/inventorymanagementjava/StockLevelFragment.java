package com.spyderscience.inventorymanagementjava;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.spyderscience.inventorymanagementjava.adapter.StockLevelAdapter;
import com.spyderscience.inventorymanagementjava.database.DatabaseHelper;
import com.spyderscience.inventorymanagementjava.databinding.FragmentStockLevelBinding;
import com.spyderscience.inventorymanagementjava.model.HelperClass;
import com.spyderscience.inventorymanagementjava.model.ProductsModel;

import java.util.ArrayList;
import java.util.List;

public class StockLevelFragment extends Fragment {
    private FragmentStockLevelBinding binding;
    private StockLevelAdapter adapter;
    private DatabaseHelper databaseHelper;
    private List<ProductsModel> productList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentStockLevelBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Set up bottom navigation with NavController
        BottomNavigationView bottomNav = view.findViewById(R.id.bottomNavigationView);
        NavHostFragment navHostFragment = (NavHostFragment) requireActivity().getSupportFragmentManager()
                .findFragmentById(R.id.bottomNavigationView);
        if (navHostFragment != null) {
            NavigationUI.setupWithNavController(bottomNav, navHostFragment.getNavController());
        }

        // Initialize database helper
        databaseHelper = new DatabaseHelper(requireContext());

        // Set click listener for back button
        binding.backtBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavHostFragment.findNavController(StockLevelFragment.this)
                        .navigate(R.id.action_stockLevelFragment_to_dashBoardFragment2);
            }
        });
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onResume() {
        super.onResume();

        // Retrieve products for the current user
        productList.clear();
        productList.addAll(databaseHelper.getProductsByUserId(HelperClass.users.getId()));

        // Update UI based on retrieved products
        if (productList.size() > 0) {
            binding.noDataFound.setVisibility(View.GONE);
            binding.stockRecyclerView.setVisibility(View.VISIBLE);
            binding.tvQuantity.setVisibility(View.VISIBLE);
            binding.stockRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
            adapter = new StockLevelAdapter(productList, requireContext());
            binding.stockRecyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        } else {
            // Show message if no products found
            binding.noDataFound.setVisibility(View.VISIBLE);
            binding.stockRecyclerView.setVisibility(View.GONE);
            binding.tvQuantity.setVisibility(View.GONE);
        }
    }
}