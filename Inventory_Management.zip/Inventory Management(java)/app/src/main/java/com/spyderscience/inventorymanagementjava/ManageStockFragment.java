package com.spyderscience.inventorymanagementjava;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.spyderscience.inventorymanagementjava.adapter.ManageStockAdapter;
import com.spyderscience.inventorymanagementjava.database.DatabaseHelper;
import com.spyderscience.inventorymanagementjava.databinding.FragmentManageStockBinding;
import com.spyderscience.inventorymanagementjava.model.HelperClass;
import com.spyderscience.inventorymanagementjava.model.OnClick;
import com.spyderscience.inventorymanagementjava.model.ProductsModel;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ManageStockFragment extends Fragment {
    private FragmentManageStockBinding binding;
    private ManageStockAdapter adapter;
    private DatabaseHelper databaseHelper;
    private List<ProductsModel> productList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentManageStockBinding.inflate(inflater, container, false);

        // Set up bottom navigation with NavController
        BottomNavigationView bottomNav = binding.getRoot().findViewById(R.id.bottomNavigationView);
        NavHostFragment navHostFragment = (NavHostFragment) requireActivity().getSupportFragmentManager().findFragmentById(R.id.bottomNavigationView);
        if (navHostFragment != null) {
            NavigationUI.setupWithNavController(bottomNav, navHostFragment.getNavController());
        }

        // Initialize database helper
        databaseHelper = new DatabaseHelper(requireContext());

        // Set click listener for back button
        binding.backtBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavHostFragment.findNavController(ManageStockFragment.this)
                        .navigate(R.id.action_manageStockFragment2_to_dashBoardFragment2);
            }
        });

        // Set click listener for add button
        binding.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavHostFragment.findNavController(ManageStockFragment.this)
                        .navigate(R.id.action_manageStockFragment2_to_addStockFragment);
            }
        });

        return binding.getRoot();
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onResume() {
        super.onResume();

        // Retrieve products for the current user
        productList.clear();
        productList.addAll(databaseHelper.getProductsByUserId(HelperClass.users.getId()));

        // Update UI based on retrieved products
        if (productList.size() > 0) {
            binding.noDataFound.setVisibility(View.GONE);
            binding.stockRecyclerView.setVisibility(View.VISIBLE);
            binding.stockRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
            adapter = new ManageStockAdapter(productList, requireContext(), new OnClick() {
                @Override
                public void clicked(int pos, String from) {
                    ProductsModel productsModel = productList.get(pos);
                    if (Objects.equals(from, "edit")) {
                        // Navigate to EditFragment with product data
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("data", productsModel);
                        NavHostFragment.findNavController(ManageStockFragment.this)
                                .navigate(R.id.action_manageStockFragment2_to_editFragment, bundle);
                    } else {
                        // Delete product and update UI
                        databaseHelper.deleteProduct(productsModel.getProductId());
                        productList.remove(pos);
                        adapter.notifyDataSetChanged();
                    }
                }
            });
            binding.stockRecyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        } else {
            // Show message if no products found
            binding.noDataFound.setVisibility(View.VISIBLE);
            binding.stockRecyclerView.setVisibility(View.GONE);
        }
    }
}
