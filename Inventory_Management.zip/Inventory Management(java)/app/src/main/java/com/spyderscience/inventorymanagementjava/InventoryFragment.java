package com.spyderscience.inventorymanagementjava;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.spyderscience.inventorymanagementjava.adapter.InventoryAdapter;
import com.spyderscience.inventorymanagementjava.database.DatabaseHelper;
import com.spyderscience.inventorymanagementjava.databinding.FragmentInventoryBinding;
import com.spyderscience.inventorymanagementjava.model.HelperClass;
import com.spyderscience.inventorymanagementjava.model.ProductsModel;

import java.util.ArrayList;
import java.util.List;

public class InventoryFragment extends Fragment {
    private FragmentInventoryBinding binding;
    private InventoryAdapter adapter;
    private DatabaseHelper databaseHelper;
    private List<ProductsModel> list = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentInventoryBinding.inflate(inflater, container, false);

        // Set up bottom navigation with NavController
        BottomNavigationView bottomNav = binding.getRoot().findViewById(R.id.bottomNavigationView);
        NavHostFragment navHostFragment = (NavHostFragment) requireActivity().getSupportFragmentManager().findFragmentById(R.id.bottomNavigationView);
        if (navHostFragment != null) {
            NavigationUI.setupWithNavController(bottomNav, navHostFragment.getNavController());
        }

        databaseHelper = new DatabaseHelper(requireContext());

        // Set click listener for back button
        binding.backtBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavHostFragment.findNavController(InventoryFragment.this)
                        .navigate(R.id.action_inventoryFragment2_to_dashBoardFragment2);
            }
        });

        return binding.getRoot();
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onResume() {
        super.onResume();

        // Retrieve and display user's products
        list.clear();
        list.addAll(databaseHelper.getProductsByUserId(HelperClass.users.getId()));

        if (list.size() > 0) {
            binding.noDataFound.setVisibility(View.GONE);
            binding.stockRecyclerView.setVisibility(View.VISIBLE);
            binding.stockRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
            adapter = new InventoryAdapter(list, requireContext());
            binding.stockRecyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        } else {
            binding.noDataFound.setVisibility(View.VISIBLE);
            binding.stockRecyclerView.setVisibility(View.GONE);
        }
    }

}
