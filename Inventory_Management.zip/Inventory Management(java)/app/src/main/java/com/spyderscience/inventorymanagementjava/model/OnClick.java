package com.spyderscience.inventorymanagementjava.model;

public interface OnClick {
    public void clicked(int pos, String from);
}
