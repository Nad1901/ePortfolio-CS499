package com.spyderscience.inventorymanagementjava;

import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.spyderscience.inventorymanagementjava.database.DatabaseHelper;
import com.spyderscience.inventorymanagementjava.databinding.FragmentSignUpBinding;
import com.spyderscience.inventorymanagementjava.model.UsersModel;

public class SignUpFragment extends Fragment {
    private FragmentSignUpBinding binding;
    private String email, phone, password, conPassword; // Declare variables
    private DatabaseHelper databaseHelper; // Database helper instance

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentSignUpBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(requireContext());

        // Navigate back to splash screen
        binding.backtBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToSplashScreen();
            }
        });

        // Create account button click listener
        binding.createAccountBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValidated()) {
                    // Create new user model
                    UsersModel users = new UsersModel(email, phone, password);
                    // Register user in the database
                    databaseHelper.registerUser(users);
                    // Show success message
                    showMessage("Successfully Registered");
                    // Navigate to login fragment
                    navigateToLoginFragment();
                }
            }
        });

        // Already have an account text view click listener
        binding.alreadyAccountTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to login fragment
                navigateToLoginFragment();
            }
        });
    }

    // Method to validate user input
    private Boolean isValidated() {
        email = binding.emailET.getText().toString().trim();
        phone = binding.phoneET.getText().toString().trim();
        password = binding.passwordET.getText().toString().trim();
        conPassword = binding.confirmPasswordET.getText().toString().trim();

        // Validate email
        if (email.isEmpty()) {
            showMessage("Please enter email");
            return false;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showMessage("Please enter email in correct format");
            return false;
        }

        // Validate phone
        if (phone.isEmpty()) {
            showMessage("Please enter phone");
            return false;
        }

        // Validate password
        if (password.isEmpty()) {
            showMessage("Please enter password");
            return false;
        }
        if (conPassword.isEmpty()) {
            showMessage("Please enter confirm password");
            return false;
        }
        if (!password.equals(conPassword)) {
            showMessage("Passwords do not match");
            return false;
        }

        return true;
    }

    // Method to display toast message
    private void showMessage(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }

    // Method to navigate to splash screen fragment
    private void navigateToSplashScreen() {
        NavHostFragment.findNavController(SignUpFragment.this)
                .navigate(R.id.action_signUpFragment_to_splashScreen2Fragment);
    }

    // Method to navigate to login fragment
    private void navigateToLoginFragment() {
        NavHostFragment.findNavController(SignUpFragment.this)
                .navigate(R.id.action_signUpFragment_to_loginFragment);
    }
}