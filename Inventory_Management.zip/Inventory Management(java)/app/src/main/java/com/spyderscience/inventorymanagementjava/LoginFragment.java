package com.spyderscience.inventorymanagementjava;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.spyderscience.inventorymanagementjava.database.DatabaseHelper;
import com.spyderscience.inventorymanagementjava.databinding.FragmentLoginBinding;
import com.spyderscience.inventorymanagementjava.model.HelperClass;
import com.spyderscience.inventorymanagementjava.model.UsersModel;

import java.util.ArrayList;
import java.util.List;

public class LoginFragment extends Fragment {
    private FragmentLoginBinding binding;
    private String email, password;
    private DatabaseHelper databaseHelper;
    private boolean isDetailsValid = false;
    private List<UsersModel> userList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentLoginBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Request SMS permission if not granted
        if (ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{android.Manifest.permission.SEND_SMS}, 100);
        }

        // Initialize database helper
        databaseHelper = new DatabaseHelper(requireContext());

        // Navigate to sign up fragment when back button is clicked
        binding.backtBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToSignUpFragment();
            }
        });

        // Login button click listener
        binding.logInBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Validate user input
                if (isValidated()){
                    // Retrieve list of users from database
                    userList = databaseHelper.getAllUsers();
                    // Iterate through users list
                    for (UsersModel user : userList) {
                        // Check if email and password match any user
                        if (email.equals(user.getEmail()) && password.equals(user.getPassword())) {
                            // Set flag to indicate successful login
                            isDetailsValid = true;
                            // Show success message
                            showMessage("Successfully Logged In");
                            // Store logged-in user
                            HelperClass.users = user;
                            // Navigate to dashboard fragment
                            navigateToDashboardFragment();
                            break;
                        }
                    }
                    // If no match found, show error message
                    if (!isDetailsValid) {
                        showMessage("Wrong Credentials...\nPlease check email or password");
                    }
                }
            }
        });
    }

    // Method to validate user input
    private boolean isValidated() {
        email = binding.emailET.getText().toString().trim();
        password = binding.passwordET.getText().toString().trim();

        if (email.isEmpty()) {
            showMessage("Please enter email");
            return false;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showMessage("Please enter a valid email address");
            return false;
        }
        if (password.isEmpty()) {
            showMessage("Please enter password");
            return false;
        }
        return true;
    }

    // Method to display toast message
    private void showMessage(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }

    // Method to navigate to sign up fragment
    private void navigateToSignUpFragment() {
        NavHostFragment.findNavController(LoginFragment.this)
                .navigate(R.id.action_loginFragment_to_signUpFragment);
    }

    // Method to navigate to dashboard fragment
    private void navigateToDashboardFragment() {
        NavHostFragment.findNavController(LoginFragment.this)
                .navigate(R.id.action_loginFragment_to_dashBoardFragment2);
    }
}