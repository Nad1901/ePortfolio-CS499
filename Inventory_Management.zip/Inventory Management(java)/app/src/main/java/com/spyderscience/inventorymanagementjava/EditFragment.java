package com.spyderscience.inventorymanagementjava;

import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.spyderscience.inventorymanagementjava.database.DatabaseHelper;
import com.spyderscience.inventorymanagementjava.databinding.FragmentEditBinding;
import com.spyderscience.inventorymanagementjava.model.HelperClass;
import com.spyderscience.inventorymanagementjava.model.ProductsModel;

public class EditFragment extends Fragment {
    private FragmentEditBinding binding;
    private ProductsModel productsModel;
    private int quantity = 0;
    private DatabaseHelper databaseHelper;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            // Retrieve product data passed from arguments
            productsModel = (ProductsModel) getArguments().getSerializable("data");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentEditBinding.inflate(inflater, container, false);
        View view = binding.getRoot();

        // Setup bottom navigation view
        BottomNavigationView bottomNav = view.findViewById(R.id.bottomNavigationView);
        NavHostFragment navHostFragment = (NavHostFragment) requireActivity().getSupportFragmentManager().findFragmentById(R.id.bottomNavigationView);
        if (navHostFragment != null) {
            NavigationUI.setupWithNavController(bottomNav, navHostFragment.getNavController());
        }

        // Initialize database helper
        databaseHelper = new DatabaseHelper(requireContext());

        // Back button click listener
        binding.backtBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavHostFragment.findNavController(EditFragment.this)
                        .navigate(R.id.action_editFragment_to_manageStockFragment2);
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Populate views with product data
        if (productsModel != null) {
            binding.itemName.setText(productsModel.getName());
            quantity = Integer.parseInt(productsModel.getQuantity());
            binding.stock1.setText(productsModel.getQuantity());
            // Load image using Glide library
            Glide.with(binding.getRoot())
                    .asBitmap()
                    .load(Uri.parse(productsModel.getImageUri()))
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            binding.itemImage.setImageBitmap(resource);
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                            // This is called when the Drawable is cleared, for example, when the view is recycled.
                        }
                    });
        }

        // Add button click listener
        binding.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                quantity++;
                // Update product quantity in database
                productsModel.setQuantity(String.valueOf(quantity));
                databaseHelper.updateProduct(productsModel);
                binding.stock1.setText(productsModel.getQuantity());
                if (quantity < 5){
                    sendSMSNotification(productsModel);
                }
            }
        });

        // Minus button click listener
        binding.minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (quantity > 0) {
                    quantity--;
                    // Update product quantity in database
                    productsModel.setQuantity(String.valueOf(quantity));
                    databaseHelper.updateProduct(productsModel);
                    binding.stock1.setText(productsModel.getQuantity());
                    if (quantity < 5){
                        sendSMSNotification(productsModel);
                    }
                }
            }
        });

    }

    // Send SMS notification about low inventory
    private void sendSMSNotification(ProductsModel productsModel) {
        if (ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(HelperClass.users.getPhone(), null, productsModel.getName()+" has low inventory, Please make sure the quantity 5 or above", null, null);
        }
    }

}
